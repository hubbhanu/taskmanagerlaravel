@props(['buttonName'])
<div class="mt-6">
    <button class="px-4 py-1 text-white font-light tracking-wider bg-blue-500 rounded"
        type="submit" {{ $attributes }}>{{ $buttonName }}</button>
</div>
