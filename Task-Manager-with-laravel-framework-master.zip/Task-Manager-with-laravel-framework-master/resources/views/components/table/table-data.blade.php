@props(['tdName'])
<td class="py-4 px-6 border-b border-grey-light">{{ $tdName }}</td>
